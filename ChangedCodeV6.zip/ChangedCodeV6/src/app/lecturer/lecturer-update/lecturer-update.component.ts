import { Component, OnInit, ViewChild, Input, EventEmitter, Output, ElementRef } from '@angular/core';
import { LecturerService } from 'src/app/lecturer/shared/services/lecturer.service';
import { Lecturer } from 'src/app/lecturer/shared/models/lecturer.model';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm, FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-lecturer-update',
  templateUrl: './lecturer-update.component.html',
  styleUrls: ['./lecturer-update.component.css']
})
export class LecturerUpdateComponent implements OnInit {

  constructor(private service: LecturerService, private route: Router, private toastr: ToastrService,
    private formBuilder: FormBuilder, private activatedRoute: ActivatedRoute) { }
  form: FormGroup;
  editButtonName: boolean;
  submitButtonName: boolean;
  idNumber: number;

  ngOnInit() {
    this.formLoad();
  }

  formLoad() {

    this.activatedRoute.queryParams.subscribe((params: any) => {

      if (params.id) {
        this.idNumber = Number.parseInt(params.id, 10);
      }
    });
    this.form = this.formBuilder.group({
      lecturerID: new FormControl('', [Validators.required]),
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      dateofBirth: new FormControl('', [Validators.required]),
      dateofJoin: new FormControl('', [Validators.required]),
      contactEmail: new FormControl('', [Validators.required, Validators.email]),
      gender: new FormControl('', [Validators.required]),
      contactAddress: new FormControl('', [Validators.required]),
      lecturerCategory: new FormControl('', [Validators.required]),
      lecturerContract: new FormControl('', [Validators.required]),
      lecturerQualification: new FormControl('', [Validators.required]),
    });

    this.form.reset();

    this.getRecord(this.idNumber);
    this.form.disable();
    this.editButtonName = false;
    this.submitButtonName = true;
  }
  formControls() { return this.form.controls; }

  reset() {
    this.formLoad();
  }

  enableUpdate() {
    this.form.enable();
    this.editButtonName = true;
    this.submitButtonName = false;
  }


  onSubmit() {
    const lec = this.Register();

    this.service.putLecturer(lec).subscribe(res => {
      // Todo: Needs to update on the toast message
      this.toastr.success('Updated Sucessfully', 'Swinburne Register');
      this.formLoad();
    });
  }

  getRecord(id: number) {
    this.service.getLecturer(id).subscribe(res => {
      //console.log(res);
      this.form.patchValue(res);
    });
  }

  Register(): Lecturer {

    const lecturer = new Lecturer();
    lecturer.LecturerID = this.form.value.lecturerID;
    lecturer.FirstName = this.form.value.firstName;
    lecturer.LastName = this.form.value.lastName;
    lecturer.DateofBirth = this.form.value.dateofBirth;
    lecturer.DateofJoin = this.form.value.dateofJoin;
    lecturer.ContactEmail = this.form.value.contactEmail;
    lecturer.Gender = this.form.value.gender;
    lecturer.ContactAddress = this.form.value.contactAddress;
    lecturer.LecturerCategory = this.form.value.lecturerCategory;
    lecturer.LecturerContract = this.form.value.lecturerContract;
    lecturer.LecturerQualification = this.form.value.lecturerQualification;

    return lecturer;
  }

  delete() {
    if (confirm('Are you sure to delete this record?')) {
      this.service.deleteLecturer(this.idNumber).subscribe(res => {
        this.route.navigate([`lecturers`]);
      });
    }
    
  }
}
