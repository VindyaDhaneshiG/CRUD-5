import { Component, OnInit } from '@angular/core';
import { LecturerService } from '../shared/services/lecturer.service';
import { NgForm, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Lecturer } from '../shared/models/lecturer.model';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-lecturer-create',
  templateUrl: './lecturer-create.component.html',
  styleUrls: ['./lecturer-create.component.css']
})
export class LecturerCreateComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<string>();
  lecturerForm: FormGroup;
  isSubmitted = false;
  constructor(private service: LecturerService, private toastr: ToastrService, private formBuilder: FormBuilder, private router: Router) { }


  ngOnInit() {
    this.lecturerForm = this.formBuilder.group({
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      dateofBirth: new FormControl('', [Validators.required]),
      dateofJoin: new FormControl('', [Validators.required]),
      contactEmail: new FormControl('', [Validators.required, Validators.email]),
      Gender: new FormControl('', [Validators.required]),
      ContactAddress: new FormControl('', [Validators.required]),
      LecturerCategory: new FormControl('', [Validators.required]),
      LecturerContract: new FormControl('', [Validators.required]),
      LecturerQualification: new FormControl('', [Validators.required]),
    });
    this.lecturerForm.reset();
  }


  onSubmit() {
    this.isSubmitted = true;
    if (this.lecturerForm.invalid) {
      return;
    }
    this.insertRecord();
  }
  insertRecord() {
    const lecturer = this.Register();
    this.service.postLecturer(lecturer).subscribe(res => {
      this.toastr.success('Inserted Sucessfully', 'Swinburne Register');
      this.lecturerForm.reset();
    });
  }

  Register() {

    const lecturer = new Lecturer();
    lecturer.FirstName = this.lecturerForm.value.firstName;
    lecturer.LastName = this.lecturerForm.value.lastName;
    lecturer.DateofBirth = this.lecturerForm.value.dateofBirth;
    lecturer.DateofJoin = this.lecturerForm.value.dateofJoin;
    lecturer.ContactEmail = this.lecturerForm.value.contactEmail;
    lecturer.Gender = this.lecturerForm.value.Gender;
    lecturer.ContactAddress = this.lecturerForm.value.ContactAddress;
    lecturer.LecturerCategory = this.lecturerForm.value.LecturerCategory;
    lecturer.LecturerContract = this.lecturerForm.value.LecturerContract;
    lecturer.LecturerQualification = this.lecturerForm.value.LecturerQualification;

    return lecturer;
  }




}
