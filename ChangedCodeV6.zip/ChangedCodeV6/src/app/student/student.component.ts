import { Component, OnInit, ViewChild } from '@angular/core';
import { Student } from 'src/app/student/shared/models/student.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { StudentService } from './shared/services/student.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  constructor(public studentService: StudentService, private toastr: ToastrService, private router: Router) { }
  students;
  selectedStudent;
  stulist: Student[];
  dataAvailbale = false;
  tempstu: Student;
  studentList: object;

  ngOnInit() {
    this.studentService.getStudentList().subscribe(response => {
      this.studentList = response;
    });
    this.studentService.refreshList();

  }
  // @ViewChild('lecadd') addcomponent: LecturerComponent
  // @ViewChild('Lecedit') editcomponent: UpdatelecturerComponent

  loadStudentView(studentId: any) {
    //console.log(studentId);
    this.router.navigate(['students/update'], { queryParams: { id: studentId } });
  }
}
