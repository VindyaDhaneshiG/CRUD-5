import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from '../models/student.model';
import { HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  formData: Student;
  list: Student[];
  private readonly apiPathStudent = '/student';
  private readonly urlDetails = `${environment.studentApiUrl}${this.apiPathStudent}`;
  students: Observable<Student[]>;
  newlecturer: Student;


  constructor(private http: HttpClient) { }

  postStudent(formData: Student) {
    return this.http.post(this.urlDetails, formData);
  }

  refreshList() {
    this.http.get(this.urlDetails)
      .toPromise().then(res => { this.list = res as Student[]; });

  }

  putStudent(formData: Student) {
    return this.http.put(`${this.urlDetails}/${formData.StudentID}`, formData);
  }

  deleteStudent(id: number) {
    return this.http.delete(`${this.urlDetails}/${id}`);
  }
  getStudentList() {
    return this.http.get(this.urlDetails);
  }

  getLecturer2() {
    // return this.http.get<Student[]>(this.rootURL + 'Lecturers');
  }

  // //get a particular student
  GetStudent(id: number) {
    return this.http.get(`${this.urlDetails}/${id}`);
  }


  // editStudentRow(data){
  //   //console.log(data);
  //   return data;
  // }
}
