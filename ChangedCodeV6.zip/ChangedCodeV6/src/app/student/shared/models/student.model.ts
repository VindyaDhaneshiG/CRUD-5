export class Student {

    StudentID: number;
    FirstName: string;
    LastName: string;
    DateofBirth: string;
    ContactEmail: string;
    Gender: string;
    ContactAddress: string;


}
