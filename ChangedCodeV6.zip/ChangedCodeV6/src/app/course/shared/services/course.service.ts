import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Course } from '../models/course.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  formData: Course;
  list: Course[];
  private readonly apiPathStudent = '/Course';
  private readonly urlDetails = `${environment.studentApiUrl}${this.apiPathStudent}`;
  courses: Observable<Course[]>;
  newcourse: Course;

  constructor(private http: HttpClient) { }


  postCourse(formData: Course) {
    return this.http.post(this.urlDetails, formData);
  }

  putCourse(formData: Course) {
    return this.http.put(`${this.urlDetails}/${formData.CourseID}`, formData);
  }
  deleteCourse(id: number) {
    return this.http.delete(`${this.urlDetails}/${id}`);
  }
  getCourseList() {
    return this.http.get(this.urlDetails);
  }

  getCourse(id: number) {
    return this.http.get(`${this.urlDetails}/${id}`);
  }

}
