import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpParams, HttpHeaders } from '@angular/common/http';
import { ConfigComponent } from '../../../config/config.component';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Lecturer } from '../models/lecturer.model';

@Injectable({
  providedIn: 'root'
})
export class LecturerService {

  private readonly apiPath = '/lecturer';
  private readonly urlDetails = `${environment.studentApiUrl}${this.apiPath}`;

  constructor(private http: HttpClient) { }

  postLecturer(formData: Lecturer) {
    return this.http.post(this.urlDetails, formData);
  }

  putLecturer(formData: Lecturer) {
    return this.http.put(`${this.urlDetails}/${formData.LecturerID}`, formData);
  }

  deleteLecturer(id: number) {
    return this.http.delete(`${this.urlDetails}/${id}`);
  }


  getLecturer(id: number) {
    return this.http.get(`${this.urlDetails}/${id}`);
  }

  getAllLecturers() {
    return this.http.get<Lecturer[]>(`${this.urlDetails}`);
  }
}


