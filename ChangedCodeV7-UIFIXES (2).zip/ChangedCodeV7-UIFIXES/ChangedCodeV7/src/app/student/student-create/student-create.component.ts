import { Component, OnInit } from '@angular/core';
import { StudentService } from '../shared/services/student.service';
import { NgForm, FormGroup, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Student } from '../shared/models/student.model';
import { FormBuilder, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
// import { ValidatePassword } from "./must-match/validate-password";
@Component({
  selector: 'app-student-create',
  templateUrl: './student-create.component.html',
  styleUrls: ['./student-create.component.css']
})
export class StudentCreateComponent implements OnInit {

  constructor(private service: StudentService, private toastr: ToastrService, private router: Router, private formBuilder: FormBuilder) { }

  @Output() nameEvent = new EventEmitter<string>();


  studentForm: FormGroup;
  isSubmitted = false;

  ngOnInit() {
    this.studentForm = new FormGroup({
      firstName: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern('^[_A-z0-9]*((-|\s)*[_A-z0-9])*$')]),
      lastName: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern('^[_A-z0-9]*((-|\s)*[_A-z0-9])*$')]),
      dateofBirth: new FormControl('', [Validators.required]),
      contactEmail: new FormControl('', [Validators.required, Validators.email]),
      Gender: new FormControl('', [Validators.required]),
      contactAddress: new FormControl('', [Validators.required, Validators.minLength(2)]),

    });

    this.studentForm.reset();
  }

  formControls() { return this.studentForm.controls; }
  onSubmit() {

    this.isSubmitted = true;
    if (this.studentForm.invalid) {
      return;
    }
    this.insertRecord();

  }

  insertRecord() {
    const student = this.Register();
    //console.log(student);
    this.service.postStudent(student).subscribe(res => {
      // Todo: Needs to update on the toast message
      this.toastr.success('Inserted Sucessfully', 'Swinburne Register');
      this.studentForm.reset();
    });
  }

  Register(): Student {

    const student = new Student();
    student.FirstName = this.studentForm.value.firstName;
    student.LastName = this.studentForm.value.lastName;
    student.DateofBirth = this.studentForm.value.dateofBirth;
    student.ContactEmail = this.studentForm.value.contactEmail;
    student.Gender = this.studentForm.value.Gender;
    student.ContactAddress = this.studentForm.value.contactAddress;

    return student;

  }


}
