import { Component, OnInit } from '@angular/core';
import { CourseService } from '../shared/services/course.service';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Course } from '../shared/models/course.model';
@Component({
  selector: 'app-course-create',
  templateUrl: './course-create.component.html',
  styleUrls: ['./course-create.component.css']
})
export class CourseCreateComponent implements OnInit {

  form: FormGroup;
  isSubmitted = false;
  constructor(private service: CourseService, private toastr: ToastrService, private formBuilder: FormBuilder) { }


  ngOnInit() {
    this.form = this.formBuilder.group({
      courseName: new FormControl('', [Validators.required]),
      courseDuration: new FormControl('', [Validators.required]),
      courseType: new FormControl('', [Validators.required]),
      facultyOffer: new FormControl('', [Validators.required]),
      coursePrerequisites: new FormControl('', [Validators.required]),
    });
    this.form.reset();
  }

  onSubmit() {

    this.isSubmitted = true;
    if (this.form.invalid) {
      return;
    }
    this.insertRecord();
  }
  insertRecord() {
    const course = this.Register();
    this.service.postCourse(course).subscribe(res => {
      this.toastr.success('Inserted Sucessfully', 'Swinburne Register');
      this.form.reset();
    });
  }

  Register() {

    const course = new Course();
    course.CourseName = this.form.value.courseName;
    course.CourseDuration = this.form.value.courseDuration;
    course.CourseType = this.form.value.courseType;
    course.FacultyOffer = this.form.value.facultyOffer;
    course.CoursePrerequisites = this.form.value.coursePrerequisites;
    return course;
  }

}
