import { Component, OnInit } from '@angular/core';
import { CourseService } from '../shared/services/course.service';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Course } from '../shared/models/course.model';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-course-update',
  templateUrl: './course-update.component.html',
  styleUrls: ['./course-update.component.css']
})
export class CourseUpdateComponent implements OnInit {
  constructor(private service: CourseService, private route: Router, private toastr: ToastrService,
    private formBuilder: FormBuilder, private activatedRoute: ActivatedRoute) { }
  form: FormGroup;
  editButtonName: boolean;
  submitButtonName: boolean;
  idNumber: number;

  ngOnInit() {
    this.formLoad();
  }

  formLoad() {

    this.activatedRoute.queryParams.subscribe((params: any) => {

      if (params.id) {
        this.idNumber = Number.parseInt(params.id, 10);
      }
    });
    this.form = this.formBuilder.group({
      courseID: new FormControl('', [Validators.required]),
      courseName: new FormControl('', [Validators.required]),
      courseDuration: new FormControl('', [Validators.required]),
      courseType: new FormControl('', [Validators.required]),
      facultyOffer: new FormControl('', [Validators.required]),
      coursePrerequisites: new FormControl('', [Validators.required]),
    });

    this.form.reset();

    this.getRecord(this.idNumber);
    this.form.disable();
    this.editButtonName = false;
    this.submitButtonName = true;
  }
  formControls() { return this.form.controls; }

  reset() {
    this.formLoad();
  }

  enableUpdate() {
    this.form.enable();
    this.editButtonName = true;
    this.submitButtonName = false;
  }


  onSubmit() {
    
    const course = this.Register();
    // console.log(course);
    this.service.putCourse(course).subscribe(res => {
      // Todo: Needs to update on the toast message
      this.toastr.success('Updated Sucessfully', 'Swinburne Register');
      this.formLoad();
    });
  }

  getRecord(id: number) {
    this.service.getCourse(id).subscribe(res => {
      // console.log(res);
      this.form.patchValue(res);
    });
  }

  Register(): Course {

    const course = new Course();
    course.CourseID = this.form.value.courseID;
    course.CourseName = this.form.value.courseName;
    course.CourseDuration = this.form.value.courseDuration;
    course.CoursePrerequisites = this.form.value.coursePrerequisites;
    course.CourseType = this.form.value.courseType;
    course.FacultyOffer = this.form.value.facultyOffer;

    return course;
  }

  delete() {
    if (confirm('Are you sure to delete this record?')) {
      this.service.deleteCourse(this.idNumber).subscribe(res => {
        this.route.navigate([`courses`]);
      });
    }
  }


  enroll() {
    this.route.navigate(['/enrolled/students'], { queryParams: { id: this.idNumber } });
  }
}

