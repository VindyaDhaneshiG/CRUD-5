import { Component, OnInit, ViewChild } from '@angular/core';
import { LecturerService } from 'src/app/lecturer/shared/services/lecturer.service';
import { Lecturer } from 'src/app/lecturer/shared/models/lecturer.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-lecturer',
  templateUrl: './lecturer.component.html',
  styleUrls: ['./lecturer.component.css']
})

export class LecturerComponent implements OnInit {
  list: object;
  constructor(public lecturerService: LecturerService, private toastr: ToastrService, private route: Router) { }

  ngOnInit() {
    this.lecturerService.getAllLecturers().subscribe(res => {
      this.list = res;

    });

  }

  loadStudentView(lecId: any) {
    //console.log(lecId);
    this.route.navigate(['lecturers/update'], { queryParams: { id: lecId } });
  }
}
